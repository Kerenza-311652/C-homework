#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 联系人结构体
typedef struct Contact
{
    char name[50];
    char phone[20];
    char email[50];
    int interactionCount;  // 记录与该联系人的互动次数
    struct Contact *next;
} Contact;


// 分组结构体
typedef struct Group
{
    char groupName[50];
    Contact *contacts; // 每个分组中设置一个联系人链表
    struct Group *next;
} Group;

// 全局的通讯录链表头指针和分组链表头指针
Contact *contactsList = NULL;
Group *groupsList = NULL;

// 1. 添加联系人
// 检查输入的姓名是否已存在
int contactNameExists(const char *name)
{
    Contact *current = contactsList;
    while (current != NULL)
    {
        if (strcmp(current->name, name) == 0)
        {
            return 1;
        }
        current = current->next;
    }
    return 0;
}

// 用新数据修改同名联系人信息
void modifyContactWithNewData(const char *name)
{
    Contact *current = contactsList;
    while (current != NULL)
    {
        if (strcmp(current->name, name) == 0)
        {
            printf("\t\t请输入新的联系人电话: ");
            scanf("%s", current->phone);
            printf("\t\t请输入新的联系人邮箱: ");
            scanf("%s", current->email);
            printf("\t\t联系人信息已更新！\n");
            return;
        }
        current = current->next;
    }
    printf("\t\t查找同名联系人失败，无法更新信息！\n");
}

// 添加联系人
void addContact()
{
    char choice;
    do
    {
        Contact *newContact = (Contact *)malloc(sizeof(Contact));
        if (newContact == NULL)
        {
            printf("\t\t内存不足，添加失败！\n");
            return;
        }        
        newContact->interactionCount = 0;// 初始化interactionCount为0，即互动次数为0
        int flag; // 标记是否输入错误
        printf("\t\t请输入联系人姓名: ");
        do
        {
            flag = 0;
            scanf("%s", newContact->name);
            for (int i = 0; newContact->name[i] != '\0'; i++)// 检查输入是否合法
            {
                if (!((newContact->name[i] >= 'a' && newContact->name[i] <= 'z') ||
                      (newContact->name[i] >= 'A' && newContact->name[i] <= 'Z') ||
                      (newContact->name[i] >= '0' && newContact->name[i] <= '9') ||
                      (newContact->name[i] & 0x80) || newContact->name[i] == ' ' || newContact->name[i] == '-'))
                {
                    printf("\t\t姓名输入不合法，请重新输入！只能包含字母、数字、中文及常见符号（空格、'-'）:");
                    flag = 1;
                    break;
                }
            }
            // 检查姓名是否已存在
            if (contactNameExists(newContact->name))
            {
                char choice;
                printf("\t\t该姓名的联系人已存在，是否要覆盖原有联系人信息？(Y/N)");
                scanf(" %c", &choice); // 这里加空格，避免读取残留换行符导致误判
                if (choice == 'Y' || choice == 'y')
                {                    
                    modifyContactWithNewData(newContact->name);// 调用修改联系人信息函数，将新信息覆盖旧信息
                    free(newContact); // 释放已分配的内存
                    return; 
                }
                else
                {
                    continue;
                }
            }

        } while (flag);

        printf("\t\t请输入联系人电话: ");
        do
        {
            flag = 0;
            scanf("%s", newContact->phone);
            int phoneLength = strlen(newContact->phone);
            if (phoneLength != 11)
            {
                printf("\t\t电话号码长度应为11位，请重新输入:");
                flag = 1;
            }// 检查电话号码位数是否正确
        } while (flag);

        printf("\t\t请输入联系人邮箱: ");
        do
        {
            flag = 0;
            scanf("%s", newContact->email);
            if (strchr(newContact->email, '@') == NULL || strchr(newContact->email, '.') == NULL)
            {
                printf("\t\t邮箱格式不正确，请重新输入:");
                flag = 1;
            }// 检查邮箱格式是否正确
        } while (flag);
        newContact->next = contactsList;
        contactsList = newContact;
        printf("\t\t联系人添加成功！\n");
        printf("\t\t是否继续添加联系人？(Y/N): ");
        scanf(" %c", &choice); // 这里加了空格，避免读取残留的换行符
    } while (choice == 'Y' || choice == 'y');
}

// 删除联系人
void deleteContact() {
    char nameToDelete[50];
    char choice;

    do {
        printf("\t\t请输入要删除的联系人姓名: ");
        scanf("%s", nameToDelete);

        Contact *prev = NULL;
        Contact *current = contactsList;
        while (current != NULL) {
            if (strcmp(current->name, nameToDelete) == 0) {
                if (prev == NULL) {
                    contactsList = current->next;
                } else {
                    prev->next = current->next;
                }// 找到对应联系人
                free(current);
                printf("\t\t联系人删除成功！\n");
                break;
            }
            prev = current;
            current = current->next;
        }

        if (current == NULL) {
            printf("\t\t未找到该联系人，删除失败！\n");
        }
        printf("\t\t是否继续删除联系人？(Y/N): ");
        scanf(" %c", &choice); // 这里加了空格，避免读取残留的换行符
    } while (choice == 'Y' || choice == 'y'); 
}

// 3. 修改联系人信息
void modifyContact() {
    char nameToModify[50];
    char choice;
    do {
        printf("\t\t请输入要修改信息的联系人姓名: ");
        scanf("%s", nameToModify);
        Contact *current = contactsList;
        while (current != NULL) {
            if (strcmp(current->name, nameToModify) == 0)
                break;
            current = current->next;
        }
        if (current == NULL) {
            printf("\t\t未找到该联系人，修改失败！\n");
        } else {
            current->interactionCount++;  // 每次修改增加互动次数
            printf("\t\t请选择要修改的内容：\n");
            printf("\t\t1.联系人姓名\n");
            printf("\t\t2.联系人电话\n");
            printf("\t\t3.联系人邮箱\n");
            printf("\t\t请输入您的选择：");
            int choice;
            scanf("%d", &choice);
            switch (choice) {
                case 1:
                    printf("\t\t请输入新的联系人姓名：");
                    scanf("%s", current->name);
                    break;
                case 2:
                    printf("\t\t请输入新的联系人电话: ");
                    scanf("%s", current->phone);
                    break;
                case 3:
                    printf("\t\t请输入新的邮箱：");
                    scanf("%s", current->email);
                    break;
            }
            printf("\t\t联系人信息修改成功！\n");
        }
        printf("\t\t是否继续修改联系人？(Y/N): ");
        scanf(" %c", &choice);
    } while (choice == 'Y' || choice == 'y');
}

// 4. 查找联系人
void searchContact() {
    char nameToSearch[50];
    char choice;

    do {
        printf("\t\t请输入要查找的联系人姓名: ");
        scanf("%s", nameToSearch);
        Contact *current = contactsList;
        while (current != NULL) {
            if (strcmp(current->name, nameToSearch) == 0) {
                current->interactionCount++;// 每次查询增加互动次数
                printf("\t\t姓名: %s\n", current->name);
                printf("\t\t电话: %s\n", current->phone);
                printf("\t\t邮箱: %s\n", current->email);
                break;
            }
            current = current->next;
        }
        if (current == NULL) {
            printf("\t\t未找到该联系人！\n");
        }
        printf("\t\t是否继续查找联系人？(Y/N): ");
        scanf(" %c", &choice);
    } while (choice == 'Y' || choice == 'y');
}

// 5. 显示通讯录
void displayContacts()
{
    Contact *current = contactsList;
    if (current == NULL)
    {
        printf("\t\t通讯录为空！\n");
        return;
    }
    printf("\t\t通讯录联系人列表:\n");
    while (current != NULL)
    {
        printf("\t\t姓名: %s\n", current->name);
        printf("\t\t电话: %s\n", current->phone);
        printf("\t\t邮箱: %s\n", current->email);
        printf("\t\t----------------\n");
        current = current->next;
    }
}

// 6. 设置分组
void addGroup()
{
    Group *newGroup = (Group *)malloc(sizeof(Group));
    if (newGroup == NULL)
    {
        printf("\t\t内存分配失败！\n");
        return;
    }

    printf("\t\t请输入分组名称: ");
    scanf("%s", newGroup->groupName);
    newGroup->contacts = NULL;
    newGroup->next = groupsList;
    groupsList = newGroup;
    printf("\t\t分组添加成功！\n");
}

// 7. 将联系人加入分组
void addContactToGroup()
{
    char contactName[50];
    char groupName[50];
    printf("\t\t请输入要加入分组的联系人姓名: ");
    scanf("%s", contactName);
    printf("\t\t请输入分组名称: ");
    scanf("%s", groupName);

    Contact *contact = contactsList; // 寻找对应联系人
    while (contact != NULL && strcmp(contact->name, contactName) != 0)
    {
        contact = contact->next;
    }
    if (contact == NULL)
    {
        printf("\t\t未找到该联系人！\n");
        return;
    }

    Group *group = groupsList; // 寻找对应分组
    while (group != NULL && strcmp(group->groupName, groupName) != 0)
    {
        group = group->next;
    }
    if (group == NULL)
    {
        printf("\t\t未找到该分组！\n");
        return;
    }

    // 将联系人信息加入分组链表中
    Contact *prev = NULL;
    Contact *current = group->contacts;
    while (current != NULL)
    {
        prev = current;
        current = current->next;
    }
    if (prev == NULL)
    {
        group->contacts = contact;
    }
    else
    {
        prev->next = contact;
    }
    contact->next = NULL;
    printf("\t\t联系人已成功加入分组！\n");
}

// 8. 模糊查找
void fuzzySearch()
{
    char keyword[50];
    printf("\t\t请输入模糊查找的关键字: ");
    scanf("%s", keyword);

    Contact *current = contactsList;
    int found = 0; // 标记是否找到匹配的联系人
    while (current != NULL)
    {
        if (strstr(current->name, keyword) != NULL ||
            strstr(current->phone, keyword) != NULL ||
            strstr(current->email, keyword) != NULL) // 检查当前联系人的姓名、电话、邮箱字段中是否包含输入的关键字
        {
            printf("\t\t姓名: %s\n", current->name);
            printf("\t\t电话: %s\n", current->phone);
            printf("\t\t邮箱: %s\n", current->email);
            printf("\t\t----------------\n");
            found = 1;
        }
        current = current->next;
    }
    if (!found)
    {
        printf("\t\t未找到匹配的联系人！\n");
    }
}

// 9. 读取通讯录文件（假设文件格式为每行一个联系人，格式为"姓名 电话 邮箱"）
void readContactsFromFile()
{
    FILE *fp = fopen("contacts。txt", "r");
    if (fp == NULL)
    {
        printf("\t\t无法打开文件！\n");
        return;
    }

    char line[150];
    while (fgets(line, sizeof(line), fp) != NULL)
    {
        Contact *newContact = (Contact *)malloc(sizeof(Contact));
        if (newContact == NULL)
        {
            printf("\t\t内存分配失败！\n");
            continue;
        }

        sscanf(line, "%s %s %s", newContact->name, newContact->phone, newContact->email);
        newContact->next = contactsList;
        contactsList = newContact;
    }

    fclose(fp);
    printf("\t\t通讯录文件读取成功！\n");
}

// 10. 通讯录文件存档（按每行一个联系人，格式为"姓名 电话 邮箱"写入文件）
void saveContactsToFile()
{
    FILE *fp = fopen("contacts.txt", "w");
    if (fp == NULL)
    {
        printf("\t\t无法打开文件！\n");
        return;
    }

    Contact *current = contactsList;
    while (current != NULL)
    {
        fprintf(fp, "%s %s %s\n", current->name, current->phone, current->email);
        current = current->next;
    }

    fclose(fp);
    printf("\t\t通讯录已成功存档！\n");
}

// 11.根据互动次数排序并显示联系人
void displayInteractionRank()
{
    if (contactsList == NULL)
    {
        printf("\t\t通讯录为空！\n");
        return;
    }

    // 使用冒泡排序按照互动次数排序
    Contact *current, *next;
    for (current = contactsList; current != NULL; current = current->next)
    {
        for (next = current->next; next != NULL; next = next->next)
        {
            if (current->interactionCount < next->interactionCount)
            {
                char tempName[50], tempPhone[20], tempEmail[50];
                int tempInteractionCount;
                strcpy(tempName, current->name);
                strcpy(tempPhone, current->phone);
                strcpy(tempEmail, current->email);
                tempInteractionCount = current->interactionCount;
                
                strcpy(current->name, next->name);
                strcpy(current->phone, next->phone);
                strcpy(current->email, next->email);
                current->interactionCount = next->interactionCount;

                strcpy(next->name, tempName);
                strcpy(next->phone, tempPhone);
                strcpy(next->email, tempEmail);
                next->interactionCount = tempInteractionCount;
            }
        }
    }

    // 输出排行榜
    printf("\t\t联系频率排行榜:\n");
    Contact *currentContact = contactsList;
    while (currentContact != NULL)
    {
        printf("\t\t姓名: %s\n", currentContact->name);
        printf("\t\t电话: %s\n", currentContact->phone);
        printf("\t\t邮箱: %s\n", currentContact->email);
        printf("\t\t互动次数: %d\n", currentContact->interactionCount);
        printf("\t\t----------------\n");
        currentContact = currentContact->next;
    }
}


// 12. 退出程序
void exitProgram()
{
    // 释放通讯录链表内存
    Contact *currentContact = contactsList;
    Contact *nextContact;
    while (currentContact != NULL)
    {
        nextContact = currentContact->next;
        free(currentContact);
        currentContact = nextContact;
    }

    // 释放分组链表内存
    // 仅释放分组链表中的分组，不再释放联系人
    Group *currentGroup = groupsList;
    Group *nextGroup;
    while (currentGroup != NULL)
    {
        nextGroup = currentGroup->next;
        free(currentGroup);
        currentGroup = nextGroup;
    }

    printf("\t\t程序已退出！\n");
    exit(0);
}

int main()
{
    int choice;
    while (1)
    {
        printf("\n\t\t\t\t通讯录管理系统\t\t\t\t\n");
        printf("\t\t1. 添加联系人\n");
        printf("\t\t2. 删除联系人\n");
        printf("\t\t3. 修改联系人信息\n");
        printf("\t\t4. 查找联系人信息\n");
        printf("\t\t5. 显示通讯录\n");
        printf("\t\t6. 设置分组\n");
        printf("\t\t7. 将联系人加入分组\n");
        printf("\t\t8. 模糊查找\n");
        printf("\t\t9. 读取通讯录文件\n");
        printf("\t\t10. 通讯录文件存档\n");
        printf("\t\t11. 联系频率排行榜\n");
        printf("\t\t12. 退出\n");
        printf("\t\t请输入你的选择: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            addContact();
            break;
        case 2:
            deleteContact();
            break;
        case 3:
            modifyContact();
            break;
        case 4:
            searchContact();
            break;
        case 5:
            displayContacts();
            break;
        case 6:
            addGroup();
            break;
        case 7:
            addContactToGroup();
            break;
        case 8:
            fuzzySearch();
            break;
        case 9:
            readContactsFromFile();
            break;
        case 10:
            saveContactsToFile();
            break;
        case 11:
            displayInteractionRank();
            break;
        case 12:
            exitProgram();
            break;
        default:
            printf("\t\t无效的选择，请重新输入！\n");
        }
    }
    return 0;
}
